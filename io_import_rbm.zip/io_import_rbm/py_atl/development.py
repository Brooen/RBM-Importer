
DLL_FILES: list[str] = []


def log(msg: str) -> None:
    print(f"PyAtl: {msg}")
