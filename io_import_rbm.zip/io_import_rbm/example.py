
def run():
    from py_atl.examples import rtpc_v01

    FILE_PATH: str = r"C:\Users\abfer\work\work\jc3\extracted\locations\region_03\military\airport_02\airport_02_main.blo"

    rtpc_v01.filter_example(FILE_PATH)